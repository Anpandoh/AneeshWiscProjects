#ifndef WSH_H
#define WSH_H

#define MAX_INPUT_LENGTH 1024
#define MAX_ARGS 250
#define MAX_JOBS 250

// Add a comment or a blank line
extern int wsh_dummy;

#endif