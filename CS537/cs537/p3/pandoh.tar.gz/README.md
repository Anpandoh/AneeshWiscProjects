name: Aneesh Pandoh

cslogin: pandoh

netID: pandoh

email: pandoh@wisc.edu

status: Should pass ALL given tests

Resources Used:

ChatGPT and Stackoverflow extensivly used
