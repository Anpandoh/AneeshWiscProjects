#pragma once

#define XDIM 128
#define YDIM 128
#define ZDIM 128

constexpr int kMax = 1000;
constexpr float nuMax = 1e-3;
